# envok

A simple package to manage AWS environments for an application. Creates, updates, removes environments with configuration parameters such as account, region and custom parameters.
